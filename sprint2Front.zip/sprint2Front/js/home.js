//o plano daqui é mecher com os botoes, para aparecer no meio da tela para detalhar, como realmente um aviso msm, cheio de img,h1, e  "p"
const dadoBotao = document.querySelectorAll('botao');

dadoBotao.add
