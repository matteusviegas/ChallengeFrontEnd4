import HorarioFuncionamento from "../Components/HorarioFuncionamento"

const PageHorarioFuncionamento = ()=>{
    return(
        <>
       <HorarioFuncionamento/>
        </>
    )
    }
    export default PageHorarioFuncionamento