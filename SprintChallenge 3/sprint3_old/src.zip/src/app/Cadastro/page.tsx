import TelaCadastro from '../Components/TelaCadastro';

const Cadastro = () => {
  return <TelaCadastro />; 
};

export default Cadastro;
