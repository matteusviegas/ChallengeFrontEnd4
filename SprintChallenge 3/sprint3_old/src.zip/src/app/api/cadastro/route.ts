import oracledb from 'oracledb';
import bcrypt from 'bcrypt';
import { NextResponse } from 'next/server';

// ✅ Ativando o modo THIN do Oracle (não requer Oracle Instant Client)
oracledb.thin = true;

// ✅ Configurações de conexão com o banco Oracle
const connectionConfig = {
  user: 'rm561090',                        // seu nome de usuário Oracle
  password: 'fiap25',                      // sua senha Oracle
  connectString: 'oracle.fiap.com.br:1521/orcl', // endereço do banco (host:porta/SID)
};

// ✅ Função para conectar ao banco
async function connectToDb() {
  try {
    return await oracledb.getConnection(connectionConfig);
  } catch (error) {
    console.error('Erro ao conectar ao banco de dados:', error);
    throw new Error('Erro ao conectar ao banco de dados');
  }
}

// ✅ Função que roda quando a API recebe um POST (cadastro)
export async function POST(request: Request) {
  let connection;
  try {
    // 🟦 Pegando os dados da requisição
    const { nome, email, senha } = await request.json();

    // 🔌 Conectando ao banco
    connection = await connectToDb();

    // 🔍 Verifica se o e-mail já está cadastrado
    const result = await connection.execute(
      'SELECT COUNT(*) AS total FROM Usuario_Challenge WHERE email = :email',
      [email],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    const count = result.rows?.[0]?.TOTAL || 0;

    // ⚠️ Se já existe, retorna erro
    if (count > 0) {
      return new NextResponse(
        JSON.stringify({ error: 'Email já cadastrado.' }),
        { status: 400 }
      );
    }

    // 🔐 Criptografa a senha
    const hashedPassword = await bcrypt.hash(senha, 10);

    // ✅ Insere novo usuário no banco
    await connection.execute(
      `INSERT INTO Usuario_Challenge (id_usuario, nome, email, senha)
       VALUES (gerador_id_chall.NEXTVAL, :nome, :email, :senha)`,
      { nome, email, senha: hashedPassword },
      { autoCommit: true }
    );

    // ✅ Retorno de sucesso
    return new NextResponse(
      JSON.stringify({ success: 'Usuário cadastrado com sucesso!' }),
      { status: 200 }
    );
  } catch (error) {
    // ❌ Trata erro
    const err = error as Error;
    console.error('Erro ao cadastrar:', err.message);

    return new NextResponse(
      JSON.stringify({ error: err.message || 'Erro ao cadastrar usuário.' }),
      { status: 500 }
    );
  } finally {
    // 🔒 Fecha conexão
    if (connection) await connection.close();
  }
}
