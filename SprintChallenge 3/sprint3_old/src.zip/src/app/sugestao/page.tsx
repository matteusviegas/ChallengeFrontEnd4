import Sugestoes from "../Components/Sugestao";

const Pagesugestao = ()=>{
return(
    <>
    <Sugestoes/>
    </>
)
}
export default Pagesugestao;