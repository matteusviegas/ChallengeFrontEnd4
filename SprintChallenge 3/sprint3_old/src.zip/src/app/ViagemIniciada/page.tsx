import ViagemIniciada from "../Components/ViagemIniciada";

const PageIniciada = () => {
  return (
    <>
      <ViagemIniciada />
    </>
  );
}

export default PageIniciada;
