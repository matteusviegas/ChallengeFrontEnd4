import Avisos from "../Components/Avisos";
const TelaAvisos =()=>{
    return (
        <>
        <Avisos/>


        </>
    )
    }
    
    export default Avisos;