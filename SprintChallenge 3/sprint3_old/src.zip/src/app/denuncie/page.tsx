import Denuncie from "../Components/Denuncie"

const PageDenuncie = ()=>{
    return(
        <>
     <Denuncie/>
        </>
    )
    }
    export default PageDenuncie