import TelaLogin from '../Components/TelaLogin'; 

const Login = () => {
  return <TelaLogin />; 
};

export default Login;
