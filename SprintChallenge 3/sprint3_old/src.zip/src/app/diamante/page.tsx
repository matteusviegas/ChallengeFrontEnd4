const Diamante =()=>{
    return (
        <>
         <h1>Diamante</h1>

        </>
    )
    }
    
    export default Diamante;