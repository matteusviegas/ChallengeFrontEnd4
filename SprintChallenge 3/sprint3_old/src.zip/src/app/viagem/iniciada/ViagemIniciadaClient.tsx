'use client';

import React, { useEffect, useState } from 'react';

type Props = {
  origem?: string;
  destino?: string;
};

const ViagemIniciadaClient = ({ origem, destino }: Props) => {
  const [mensagem, setMensagem] = useState('');
  const [erro, setErro] = useState('');

  useEffect(() => {
    const fetchDados = async () => {
      if (!origem || !destino) {
        setErro('Origem ou destino inválido.');
        return;
      }

      try {
        const res = await fetch(`http://localhost:8080/api/mapa/linha9?origem=${origem}&destino=${destino}`);
        const data = await res.json();
        setMensagem(`Viagem iniciada de ${origem} para ${destino}. Duração: ${data.duracao} segundos.`);
      } catch (err) {
        setErro('Erro ao buscar dados da viagem.');
      }
    };

    fetchDados();
  }, [origem, destino]);

  return (
    <div className="h-screen flex flex-col items-center justify-center text-center">
      <h1 className="text-2xl font-bold">Viagem em Andamento</h1>
      {erro ? <p className="text-red-600 mt-4">{erro}</p> : <p className="mt-4">{mensagem}</p>}
    </div>
  );
};

export default ViagemIniciadaClient;
