
import TermosUso from "../Components/TermosUso";

const TermosUsoPage = () => {
  return <TermosUso />;
};

export default TermosUsoPage;
