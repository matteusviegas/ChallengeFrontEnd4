import Header from "../Components/Header";

const PageHeader =()=>{
    return (
        <>
       <Header/>

        </>
    )
    }
    
    export default PageHeader;